using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// ---------------------------------------------------
// NAME: Personaje.cs
// STATUS: WIP
// GAMEOBJECT: Jugador
// DESCRIPTION: Este script contiene todo lo relacionado con el personaje, movimiento, salto, vida...
//
// AUTHOR: Pablo Enguix Llopis
// FEATURES ADDED: cosas hechas
//
// AUTHOR: Jorge Grau
// FEATURES ADDED: Salud y energia. Funcionalidad a la funcion Interactuar
//
// AUTHOR: Luis Belloch
// FEATURES ADDED: Correcciones a energia y vida, control de partida, recibirAtaque, mejoras de personaje
//
//
// AUTHOR: Juan Ferrera Sala
// FEATURES ADDED: Creacion del dardo localizador, esqueleto de la función Interactuar
// ---------------------------------------------------

public class Personaje : MonoBehaviour
{
    private float adelante;
    private float derecha;
    private Vector3 velocidad;

    public ControlVida barraVida;
    public ControlEnergia barraEnergia;
    controlPartida controlPartida;
    // Se usa en mecanicasPersonaje.cs para bloquear el movimiento
    public bool paralizado;

    public GameObject camaraMejora;

    public float saludMaxima = 10;

    public bool camaraSecundariaActivada = false;

    [SerializeField]

    float salud = 10;

    public GameObject dardoLocalizador;
    public GameObject camaraJugador;

    private CameraController controladorCamara;

    public GameObject minimapa;

    Interaccion interaccionActual;

    public float alcance;

    AnimTByte animTByte;
    AudioHandler audioHandler;

    public float Salud
    {
        get { return salud; }

        set
        {
            // comprueba que el valor est� dentro de los posibles
            value = Mathf.Clamp(value, 0, saludMaxima);
            salud = value;

            // establece el maximo de vida en la barra

            barraVida.maximaVida(saludMaxima);

            if (salud <= 0)
            {
                // Vuelve la camara al jugador si esta la secundaria activada
                if (camaraMejora != null)
                {
                    if (camaraMejora.GetComponent<CamaraMejora>().camara.activeSelf)
                    {

                        camaraMejora.GetComponent<CamaraMejora>().camara.SetActive(false);

                        camaraJugador.SetActive(true);

                        camaraSecundariaActivada = false;

                    }
                }
                animTByte.Muerte();
                controlPartida.GameOver();
            }
        }
    }

    [SerializeField]
    float energia = 10;

    public float energiaMaxima = 10;

    public float Energia
    {
        get { return energia; }

        set 
        {

            value = Mathf.Clamp(value, 0, energiaMaxima);

            // establece el maximo de energia en la barra

            barraEnergia.maximaEnergia(energiaMaxima);
            energia = value;
        }
    }

    [SerializeField]
    float escudo = 0;

    public GameObject campo;

    public float escudoMaximo = 0;

    public float escudoPorSegundo = 0.01f;

    public float Escudo
    {
        get { return escudo; }

        set
        {
            value = Mathf.Clamp(value, 0, escudoMaximo);
            escudo = value;
        }
    }

    public CameraController camara;
    public MovimientoPersonaje movimientoPersonaje;
    SistemaMejoras sistemaMejoras;

    public GameObject gui;
    public GameObject menu;

    private void Start()
    {
        // Busca componentes internos
        controlPartida = FindObjectOfType<controlPartida>();
        sistemaMejoras = FindObjectOfType<SistemaMejoras>();
        movimientoPersonaje = gameObject.GetComponent<MovimientoPersonaje>();
        controladorCamara = transform.GetComponentInChildren<CameraController>();
        audioHandler = gameObject.GetComponent<AudioHandler>();
        // Script de control de las animaciones
        animTByte = GetComponent<AnimTByte>();
        // Activa el sistema de mejoras y las aplica al personaje
        sistemaMejoras.MejorasPersonaje(this);
        sistemaMejoras.DesbloquearTorreta();
        sistemaMejoras.MejorasUtilidades();
        sistemaMejoras.lladamaProvisonalTorretas();

    }

    // Reasigna los valores del personaje
    public void Setup()
    {
        // reinicia la energia y la vida actuales
        Salud = saludMaxima;
        Energia = energiaMaxima;

        Escudo = escudoMaximo;
    }

    private void Update()
    {
        // Regenerar el escudo
        if (Escudo < escudoMaximo)
        {
            Escudo += escudoPorSegundo * Time.deltaTime;
        }

        // Si en algun momento la camara es destruida, vuelve la vista al jugador
        if(camaraMejora == null && camaraSecundariaActivada)
        {
            camaraJugador.SetActive(true);
            camaraSecundariaActivada = false;
        }
    }

    // Marca enemigos con raycast directamente
    public void DispararDardo()
    {
        animTByte.LanzarDardo();
        RaycastHit punto;
        // Comprueba que este apuntando a un item en el Layer Enemigo
        if (Physics.Raycast(camaraJugador.transform.position, camaraJugador.transform.forward, out punto, alcance, LayerMask.GetMask("Enemigo")))
        {
            Debug.Log(punto.transform.gameObject.name);
            // Comprueba que sea un enemigo y recoge su script Enemigo
            if (punto.transform.gameObject.TryGetComponent<ControladorEntidad>(out ControladorEntidad enemigo))
            {
                if(sistemaMejoras.mejoraDebilitante)
                {
                    Ataque ataque = new Ataque();
                    ataque.debilitacion = 0.5f;
                    enemigo.RecibeAtaque(ataque);
                }
                enemigo.Marcar();
            }
        }

        if (Physics.Raycast(camaraJugador.transform.position, camaraJugador.transform.forward, out punto, alcance, LayerMask.GetMask("Torreta")))
        {
            Debug.Log(punto.transform.gameObject.name);
            // Comprueba que sea un enemigo y recoge su script Enemigo
            if (punto.transform.gameObject.TryGetComponent<Torreta>(out Torreta torreta))
            {
                if(torreta.gameObject.name == "Sparky(Clone)")
                {
                    if (sistemaMejoras.mejoraSparky)
                    {
                        torreta.ataque += torreta.ataque * 0.5f;
                        torreta.radioExplosion +=  torreta.radioExplosion * 0.5f;
                        torreta.vidaMaxima += torreta.vidaMaxima * 0.5f;
                        torreta.cadenciaDisparo += torreta.cadenciaDisparo * 0.5f;
                    }
                }
            }
        }
    }

    public void Mover(float adelante, float derecha)
    {
        this.adelante = adelante;
        this.derecha = derecha;

        Vector3 objetivo = adelante * camara.transform.forward;
        objetivo += derecha * camara.transform.right;
        objetivo.y = 0;

        if (objetivo.magnitude > 0)
        {
            velocidad = objetivo;
        }
        else
        {
            velocidad = Vector3.zero;
        }
        movimientoPersonaje.Velocidad = objetivo;
    }

    public void Correr()
    {
        movimientoPersonaje.SetMovimientos(MovimientoPersonaje.Movimientos.Correr);
    }

    public void Caminar()
    {
        movimientoPersonaje.SetMovimientos(MovimientoPersonaje.Movimientos.Caminar);
    }

    public void Saltar()
    {
        movimientoPersonaje.Saltar();
    }

    public void Caer()
    {
        movimientoPersonaje.Caer();
    }

    public void RecibirAtaque(Ataque ataque)
    {
        audioHandler.Play(2);

        if (Escudo > 0)
        {
            // Restamos la fuerza al escudo y el escudo a la fuerza

            float auxFuerza = ataque.fuerza;

            ataque.fuerza -= Escudo;

            Escudo -= auxFuerza;

        }

        // Despues restamos la fuerza que quede a la salud
        if (ataque.fuerza > 0)
        {
            Salud -= ataque.fuerza;
        }
    }

    // Cambia a la camara secundaria o la primaria
    public void CambiarCamara()
    {

        if(camaraMejora != null)
        {
            if(camaraMejora.GetComponent<CamaraMejora>().camara.activeSelf)
            {
                // Vuelve a la camara del jugador
                camaraMejora.GetComponent<CamaraMejora>().camara.SetActive(false);
                camaraJugador.SetActive(true);
                camaraSecundariaActivada = false;
                audioHandler.Play(3);
            } 
            else
            {
                // Cambia de camara
                camaraMejora.GetComponent<CamaraMejora>().camara.SetActive(true);
                camaraJugador.SetActive(false);
                camaraSecundariaActivada = true;
                audioHandler.Play(3);
            }
        }
    }

    public void Interactuar()
    {
        RaycastHit punto;

        // No puedes interactuar con cosas cuando estas usando la camara secundaria
        if(!camaraSecundariaActivada)
        {
            // Comprueba que este apuntando a un item en el Layer Torreta
            if (Physics.Raycast(camaraJugador.transform.position, camaraJugador.transform.forward, out punto, alcance, LayerMask.GetMask("Interactuable")))
            {
                // Toma la item del RaycastHit
                GameObject itemMarcado = punto.transform.gameObject;
                if (itemMarcado.TryGetComponent(out Fantasma torreta))
                {
                    torreta.activarInvisibilidad(itemMarcado.GetComponent<Torreta>());
                }
                if (itemMarcado.TryGetComponent(out Interaccion interaccion))
                {
                    // Abrimos menu
                    interaccionActual = interaccion.Interactuar();
                    paralizado = true;
                    audioHandler.Play(3);
                }
            }
        }
    }

    public void CerrarInteraccion()
    {
        if(interaccionActual != null)
        {
            interaccionActual.Cerrar();
        }
        interaccionActual = null;
        paralizado = false;
    }
    public void PausarPartida()
    {
        if (!menu.activeSelf)
        {
            Cursor.lockState = CursorLockMode.None;
            camara.BloquearCamara(true);
            menu.SetActive(true);
            audioHandler.Play(3);
        }
        else if (menu.activeSelf)
        {
            Cursor.lockState = CursorLockMode.Locked;
            camara.BloquearCamara(false);
            menu.SetActive(false);
            audioHandler.Play(3);
        }
    }

    // SOLO PARA LAS ESCENAS: Muestra el rayo de apuntado
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.green;
        Gizmos.DrawRay(camaraJugador.transform.position, camaraJugador.transform.forward * alcance);
    }
}
